## 为什么

当前仓颉编译器在调用补全过程（call completion）相关能力上与 Kotlin 编译器 FIR 存在明显实现缺口，导致调用候选补全、约束补全与诊断一致性难以对齐。现在推进完整移植可以尽早建立稳定的 CFIR 调用补全基础设施，降低后续调用解析与类型系统演进的重复成本。

## 变更内容

- 将 Kotlin 编译器 `FirCallCompleter` 及其完整依赖链路迁移到本项目的 CFIR 体系，采用“复制粘贴级”保真迁移策略，不做最小化裁剪。
- 对迁移过程中涉及的接口、抽象类与辅助实现进行成套引入或重建，确保依赖闭包完整可编译。
- 迁移 K2/FIR 所需的约束存储与求解能力到 CFIR（以 `ConstraintStorage` 语义为核心），并保持语义等价。
- 彻底移除 K1 旧设施；对仍被 K2 流程需要的能力，不直接保留 K1 接口入口，而是在 `cfir` 命名空间重建等价实现。
- 对本项目中已存在但不完整或与上游偏离的相关声明进行对照修订，确保与迁移目标一致。
- 统一命名前缀为 `cfir`（如 `Cfir*`）并保持模块边界清晰。
- 明确本阶段**不**将 `FirCallCompleter` 接入 `CFirExpressionsResolveTransformer` 执行路径。

## 强制约束

- 禁止“自行实现”或“基于理解重写”调用补全逻辑；实现来源必须是 Kotlin 编译器对应源码的完整迁移。
- 必须完整迁移以下要素，不得按需删减：方法、接口、抽象定义、具体实现类、类型定义、依赖声明（含导入依赖与模块依赖）。
- 仅允许进行 CFIR 适配性变更：包名/前缀映射、K1 旧设施剔除与 `cfir` 内等价重建、必要的编译环境对齐；禁止语义性简化。
- `NewConstraintSystem` / `NewConstraintSystemImpl` / `ConstraintSystemBuilder` 禁止作为迁移目标直接引入本项目。
- 对 `resolve.calls.inference` 体系采用“能力迁移”原则：保留 K2 所需能力语义，在 CFIR 内重实现；K1-only 且不被需要的设施必须删除。
- 每个迁移项必须可追溯到上游来源（源文件与符号映射），并在迁移清单中记录“已迁移/已替换/不适用及理由”。

## 功能 (Capabilities)

### 新增功能
- `cfir-call-completer-port`: 提供完整的 CFIR 调用补全器与依赖基础设施，实现与 Kotlin FIR `FirCallCompleter` 语义等价的可用实现（不含 transformer 接线）。
- `cfir-call-completion-dependency-closure`: 提供调用补全所需接口、抽象层与支持组件的完整依赖闭包迁移/重建能力，并移除 K1 入口依赖。

### 修改功能
- 无。

## 影响

- 受影响模块：`cfir:cfir-common`、`cfir:cfir-cones`、`cfir:cfir-tree`、`cfir:raw-cfir:*`、`analysis:analysis-api-cfir`（按实际依赖落点调整）。
- 受影响代码类型：调用解析相关接口/抽象、候选补全过程、诊断与上下文传递结构。
- API 影响：新增或调整 CFIR 内部 SPI；要求维持接口优先设计，不向跨模块泄露实现细节。
- 兼容性：不引入 K1 包依赖；不改动 `CFirExpressionsResolveTransformer` 的现有接线行为。

## 验收标准

- 存在覆盖完整依赖闭包的迁移追溯矩阵，且无未解释缺口。
- 代码中不存在以“自研最小实现”替代上游迁移的调用补全核心逻辑。
- 调用补全链路中不存在 K1-only 旧设施直连入口；K2 所需能力均以 CFIR 等价实现承接并通过追溯矩阵证明来源。

## 迁移文件与声明清单（逐项）

以下清单以 Kotlin 上游 `compiler/fir/resolve` 中 `inference` 与 `calls` 目录为准，作为本变更“必须迁移”的文件级基线。每项都必须建立“上游声明 -> CFIR 声明”的映射记录。

### A. `resolve/inference`（必须全量迁移）

- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/FirCallCompleter.kt`  
  关键声明：`class FirCallCompleter`、`fun Candidate.computeCompletionMode` 调用路径依赖
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/ConstraintSystemCompleter.kt`  
  关键声明：`class ConstraintSystemCompleter`
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/PostponedArgumentsAnalyzer.kt`  
  关键声明：`data class ReturnArgumentsAnalysisResult`、`interface LambdaAnalyzer`、`class PostponedArgumentsAnalyzer`、`fun ConeLambdaWithTypeVariableAsExpectedTypeAtom.transformToResolvedLambda`
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/CompletionModeCalculator.kt`  
  关键声明：`fun Candidate.computeCompletionMode`
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/InferenceComponents.kt`  
  关键声明：`class InferenceComponents`
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/InferenceUtils.kt`  
  关键声明：`fun extractLambdaInfoFromFunctionType`（及同文件辅助函数）
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/ConeConstraintSystemUtilContext.kt`  
  关键声明：`object ConeConstraintSystemUtilContext`
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/FirInferenceLogger.kt`  
  关键声明：`abstract class FirInferenceLogger`（及其记录结构）
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/FirInferenceSession.kt`  
  关键声明：`class FirInferenceSession`
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/FirPCLAInferenceSession.kt`  
  关键声明：`class FirPCLAInferenceSession`、`class FirTypeVariablesAfterPCLATransformer`
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/FirDelegatedPropertyInferenceSession.kt`  
  关键声明：`class FirDelegatedPropertyInferenceSession`、`fun FirElement.isAnyOfDelegateOperators`
- `external/kotlin/compiler/fir/resolve/src/org/jetbrains/kotlin/fir/resolve/inference/CollectionLiteralBoundsCollector.kt`  
  关键声明：`sealed class CollectionLiteralBounds`、`class CollectionLiteralBoundsCollector`

### B. `resolve/calls` 根目录（必须全量迁移）

- `.../calls/ConeResolutionAtoms.kt`：`sealed class ConeResolutionAtom` 及全部 postponed atom 子类
- `.../calls/FirCallResolver.kt`：`class FirCallResolver`、`data class OverloadCandidate`、`class AllCandidatesCollector`
- `.../calls/ResolutionContext.kt`：`class ResolutionContext`
- `.../calls/ArgumentUtils.kt`：`fun FirExpression.getExpectedType` 等参数期望类型工具
- `.../calls/CallableReferenceAdaptation.kt`：`sealed class CallableReferenceConversionStrategy`
- `.../calls/QualifierReceiver.kt`：`ClassQualifierReceiver`、`PackageQualifierReceiver`、`createQualifierReceiver`
- `.../calls/ConstructorProcessing.kt`：构造调用处理函数族
- `.../calls/SuperCalls.kt`：`findTypesForSuperCandidates` 等 super 调用处理
- `.../calls/VisibilityUtils.kt`：`isVisible` 等可见性工具

### C. `resolve/calls/candidate`（必须全量迁移）

- `CallInfo.kt`：`enum class ImplicitInvokeMode`、`class CallableReferenceInfo`
- `CallKind.kt`：`sealed class CallKind`、`class ResolutionSequenceBuilder`、`buildCallKindWithCustomResolutionSequence`
- `Candidate.kt`：`class Candidate`
- `CandidateCollector.kt`：候选收集器实现
- `CandidateFactory.kt`：`class CandidateFactory`、`addSubsystemFromAtom`
- `CandidateTraversal.kt`：`processCandidatesAndPostponedAtoms`、`processPostponedAtoms`
- `CheckerSink.kt`：`class CheckerSinkImpl`
- `FirNamedReferenceWithCandidate.kt`：`class FirErrorReferenceWithCandidate`
- `errorCandidateUtils.kt`：`createErrorReferenceWithErrorCandidate`、`createErrorReferenceWithExistingCandidate`、`createErrorCandidate`、`fullyProcessCandidate`

### D. `resolve/calls/stages`（必须全量迁移）

- `ResolutionStages.kt`：所有标准 `ResolutionStage` 对象（接收者/上下文参数/隐式遮蔽等）
- `ResolutionStageRunner.kt`：`class ResolutionStageRunner`
- `TypeArgumentMapping.kt`：`sealed class TypeArgumentMapping`
- `FirArgumentsToParametersMapper.kt`：`data class ArgumentMapping`、`mapArguments`
- `CheckArguments.kt`：`object CheckArguments`
- `CheckCallableReferenceExpectedType.kt`：`class FirFakeArgumentForCallableReference` 等
- `CreateFreshTypeVariableSubstitutorStage.kt`：`object CreateFreshTypeVariableSubstitutorStage`
- `CollectTypeVariableUsagesInfo.kt`：`object CollectTypeVariableUsagesInfo`
- `ArgumentCheckingProcessor.kt`：参数校验处理器

### E. `resolve/calls/tower`（必须全量迁移）

- `FirTowerResolver.kt`：`class FirTowerResolver`
- `TowerGroup.kt`：`sealed class TowerGroupKind`、`class TowerGroup`、`enum class InvokeResolvePriority`
- `TowerResolveManager.kt`：`class TowerResolveManager`
- `TowerLevels.kt`：`enum class ProcessResult` 及 tower level 实现
- `TowerLevelHandler.kt`：`class TowerLevelProcessor`
- `FirTowerResolveTask.kt`：tower 任务模型
- `FirInvokeResolveTowerExtension.kt`：invoke 扩展解析

### F. `resolve/calls/overloads`（必须全量迁移）

- `ConeOverloadConflictResolver.kt`：`class ConeOverloadConflictResolver`、`ConeSimpleConstraintSystemImpl`
- `ConeCallConflictResolver.kt`：冲突解析基类
- `ConeCompositeConflictResolver.kt`：组合冲突解析器
- `ConeEquivalentCallConflictResolver.kt`：等价候选冲突解析
- `ConeIntegerOperatorConflictResolver.kt`：整数字面量操作符冲突解析
- `FirOverloadByLambdaReturnTypeResolver.kt`：按 lambda 返回类型重载解析
- `FirDeclarationOverloadabilityHelperImpl.kt`：声明可重载性辅助实现
- `ReplOverloadCallConflictResolver.kt`：REPL 冲突解析器

## 本项目无上游对应、需删除或替换的声明（逐项）

以下为当前仓库中“非上游 FIR 结构/命名路径”的声明。按“完整迁移”约束，应在迁移过程中删除或被上游等价实现替换，并在追溯矩阵中标记。

- `common/src/org/cangnova/cangjie/resolve/calls/Constraint.kt`：`interface Constraint`  
  处理要求：迁移到 CFIR/FIR 对应模型层后删除该 K1 风格入口。
- `common/src/org/cangnova/cangjie/resolve/calls/PostponedResolvedAtomMarker.kt`：`PostponedResolvedAtomMarker`、`CollectionLiteralAtomMarker`、`PostponedAtomWithRevisableExpectedType`、`PostponedCallableReferenceMarker`、`LambdaWithTypeVariableAsExpectedTypeMarker`  
  处理要求：用 `cfir.resolve.calls` 内对位声明替换，删除 `common.resolve.calls` 路径暴露。
- `common/src/org/cangnova/cangjie/resolve/calls/ForkPointData.kt`：当前文件无有效声明（仅注释）  
  处理要求：删除空壳文件，避免误导为已迁移能力。
- `cfir/resolve/src/org/cangnova/cangjie/cfir/resolve/inference/InferenceLogger.kt`：`CfirConstraintKind`、`CfirInitialConstraint`、`CfirVariableConstraint`、`CfirFixationReadiness`、`CfirSimpleFixationReadiness`、`InferenceLogger`  
  处理要求：替换为上游 `FirInferenceLogger.kt` 对位迁移版本，删除自研日志模型。
- `cfir/resolve/src/org/cangnova/cangjie/cfir/resolve/inference/CfirResultTypeResolver.kt`：`class CfirResultTypeResolver`  
  处理要求：若无上游同位声明支撑则删除，结果类型推断回归上游推断链路。
- `cfir/resolve/src/org/cangnova/cangjie/cfir/resolve/inference/CfirTypeVariable.kt`：`data class CfirTypeVariable`  
  处理要求：以 FIR 推断模型中的类型变量定义替换，删除简化版自研结构。
- `cfir/resolve/src/org/cangnova/cangjie/cfir/resolve/calls/stages/CfirMapArguments.kt`：`object CfirMapArguments`  
  处理要求：并入 `FirArgumentsToParametersMapper.kt` 对位迁移实现后删除该自定义 stage。
- `cfir/resolve/src/org/cangnova/cangjie/cfir/resolve/calls/stages/CfirInferTypeArguments.kt`：`object CfirInferTypeArguments`  
  处理要求：由上游 `CollectTypeVariableUsagesInfo` + `ResolutionStages` 对位实现替换后删除。
- `cfir/resolve/src/org/cangnova/cangjie/cfir/resolve/calls/overloads/CfirFlatSignature.kt`：`class CfirFlatSignature`  
  处理要求：若与上游 `ConeOverloadConflictResolver` 路线不一致，删除并改用上游对位签名模型。

说明：上述“删除/替换”是提案约束，不要求在本步骤立即改代码；实现阶段必须按清单逐项落地并在 `tasks` 打勾验证。

## ConstraintStorage 专项结论（是否重实现/抛弃）

### 现状证据

- `CfirCallCompleter`、`CfirCandidate`、`PostponedArgumentsAnalyzer` 路径已直接依赖 `ConstraintStorage` 语义与 API（如 `asReadOnlyStorage`、`currentStorage`、`buildAbstractResultingSubstitutor`、`buildCurrentSubstitutor`）。
- 上游 Kotlin 编译器中，`ConstraintStorage` 位于 `compiler/resolution.common/.../model/ConstraintStorage.kt`，是 FIR 调用补全、PCLA、重载解析、诊断映射的共用核心模型，而非可选组件。
- 当前仓库存在 `CfirConstraintStorage` 简化实现（字符串键、简化状态机、缺失上游字段与依赖关系模型），且仓库内未找到 CFIR 版 `ConstraintStorage` 正式声明。
- 上游 FIR（K2）当前仍有对 `org.jetbrains.kotlin.resolve.calls.inference.*` 历史接口的引用，但本变更要求以“语义对齐 + CFIR 重实现”替代直接迁移旧设施实现。

### 备选方案分析

- 方案 A：在 CFIR 阶段“重新设计并重写” `ConstraintStorage`  
  结论：不采纳。原因是会偏离上游行为，且与“禁止自主实现、完整迁移”约束冲突。
- 方案 B：完全抛弃 `ConstraintStorage`，改为其他约束容器  
  结论：不采纳。原因是 `FirCallCompleter`/`FirPCLAInferenceSession`/`CandidateFactory` 等链路强依赖该抽象，抛弃将导致全链路重写。
- 方案 C：完整迁移 Kotlin `ConstraintStorage`（接口+相关模型+调用点），仅做 CFIR 命名与类型适配  
  结论：采纳。该方案与“复制粘贴级迁移”一致，且能保证行为可追溯。

补充说明：
- 本变更不迁移 `NewConstraintSystem` 相关旧设施实现本体；仅迁移其在 K2 调用补全过程中必需的语义能力，并在 CFIR 命名空间重建。

### 执行决策（强制）

- **不抛弃 `ConstraintStorage`。**
- **不做自研简化重实现。**
- 采用上游 `ConstraintStorage` 语义及关联模型能力的完整迁移路径，并在 CFIR 命名空间保持一一映射。
- 现有 `CfirConstraintStorage` 及其派生简化模型纳入“删除/替换清单”，在上游等价实现接入后下线。
- `NewConstraintSystem` / `NewConstraintSystemImpl` / `ConstraintSystemBuilder` 列为“禁止迁移项”。
- 对 `resolve.calls.inference` 下的历史命名组件执行分类治理：`K2 所需语义` -> 在 `cfir` 重实现；`K1-only` -> 删除；`过渡依赖` -> 在 `cfir` 重实现后切断。

### ConstraintStorage 迁移清单（补全版）

以下清单为 `ConstraintStorage` 专项“必须迁移”文件，按层次分组。实现阶段需逐项建立映射并验收。

#### 1) 核心模型层（`resolution.common/inference/model`）

- `ConstraintStorage.kt`  
  必迁声明：`ConstraintStorage`、`ConstraintKind`、`Constraint`、`VariableWithConstraints`、`InitialConstraint`、`checkConstraint`
- `MutableConstraintStorage.kt`  
  必迁声明：`MutableVariableWithConstraints`、`MutableConstraintStorage`（含依赖关系、outer CS、fork-point 相关字段）
- `ConstraintPositionAndErrors.kt`  
  必迁声明：约束位置/错误结构（供 diagnostics 与推断流程共享）

#### 2) 抽象 API 层（`resolution.common/inference`）

- `InferenceUtils.kt`  
  必迁声明：`ConstraintStorage.buildCurrentSubstitutor`、`buildAbstractResultingSubstitutor`、`buildNotFixedVariablesToNonSubtypableTypesSubstitutor`

#### 3) 组件层（`resolution.common/inference/components`，与 ConstraintStorage 强耦合）

- `ConstraintInjector.kt`：初始约束注入、深度限制、`InitialConstraint` 记录
- `ConstraintIncorporator.kt`：约束合成与传播，依赖 `VariableWithConstraints`
- `ConstraintSystemCompletionContext.kt`：completion 阶段对 `notFixedTypeVariables` 的读取契约
- `ResultTypeResolver.kt`：基于 `VariableWithConstraints` 的求解策略
- `VariableFixationFinder.kt`：fixation 时机判定与 trivial/proper 约束过滤
- `TypeVariableDependencyInformationProvider.kt`：类型变量依赖图推导
- `PostponedArgumentInputTypesResolver.kt`：postponed 参数输入类型推导与回灌
- `InferenceLogger.kt`：约束系统日志抽象（避免自研日志模型偏差）
- `ConstraintSystemMarker.kt`、`ConstraintSystemUtilContext.kt`、`TypeCheckerStateForConstraintSystem.kt`、`TypeVariableDirectionCalculator.kt`、`VariableReadinessCalculator.kt`、`LegacyVariableReadinessCalculator.kt`、`TrivialConstraintTypeInferenceOracle.kt`、`ConstraintSystemCompletionMode.kt`

#### 4) FIR 调用链接入点（用于验收“已接上迁移版 ConstraintStorage”）

- `fir/resolve/inference/FirCallCompleter.kt`：`asReadOnlyStorage/currentStorage` + substitutor 构建
- `fir/resolve/inference/PostponedArgumentsAnalyzer.kt`：`buildCurrentSubstitutor`、merge/transaction 流程
- `fir/resolve/inference/FirPCLAInferenceSession.kt`：`currentStorage`/`replaceContentWith`/outer CS 同步
- `fir/resolve/inference/FirDelegatedPropertyInferenceSession.kt`：`currentConstraintStorage` 与 parent/child system 合并
- `fir/resolve/calls/candidate/CandidateFactory.kt`：`setBaseSystem`、`addOtherSystem`、`asReadOnlyStorage`
- `fir/resolve/calls/stages/*`（尤其 `CollectTypeVariableUsagesInfo.kt`、`ArgumentCheckingProcessor.kt`）：读取 `currentStorage().notFixedTypeVariables`

#### 5) CFIR 侧替换/下线清单（与上游迁移完成后执行）

- 下线：`cfir/resolve/.../CfirConstraintStorage.kt`（简化实现）
- 下线：`cfir/resolve/.../CfirResultTypeResolver.kt`（若与上游 `ResultTypeResolver` 路线冲突）
- 下线：`cfir/resolve/.../InferenceLogger.kt` 中自研约束日志模型（由上游对位实现替换）
- 接口切换点：`CfirCandidate.kt`、`CfirCallCompleter.kt`、`ReturnArgumentsAnalysisResult.kt` 对 `ConstraintStorage` 的引用必须切换到迁移版契约
- 禁止引入：`NewConstraintSystem`、`NewConstraintSystemImpl`、`ConstraintSystemBuilder` 的旧设施实现本体
