## 1. 迁移基线与依赖闭包梳理

- [x] 1.1 基于 Kotlin 上游源码梳理 `FirCallCompleter` 完整依赖清单（接口、抽象、实现、辅助文件）并落盘为迁移对照表
- [x] 1.2 标记对照表中的 K1 入口依赖（含 `org.jetbrains.kotlin.resolve.calls`）并为每项定义 CFIR 等价替代目标
- [x] 1.3 盘点仓库内现有相关 `Cfir*` 声明并标注“可复用/需修正/需替换/缺失”状态
- [x] 1.4 建立“上游符号 -> 本仓符号”追溯矩阵，覆盖方法、接口、抽象、具体实现类与依赖声明
- [ ] 1.5 对 `resolve.calls.inference` 依赖做分类：`K2 所需语义能力` / `K1-only` / `需CFIR重实现`，并形成治理清单（含“NewConstraintSystem 系列禁止迁移”标记）

## 2. 接口与抽象层迁移

- [ ] 2.1 在 CFIR 模块中迁移或重建调用补全所需接口层，统一命名前缀与包边界
- [ ] 2.2 迁移或重建抽象基类、上下文对象与协作契约，确保跨模块仅暴露抽象 API
- [ ] 2.3 修正本项目中与上游语义不一致或不完整的相关声明，并更新受影响调用点到新契约
- [ ] 2.4 完整迁移 `ConstraintStorage` 语义及其关联模型能力（接口、字段、约束结构、依赖关系数据），禁止继续扩展简化版实现

## 3. CfirCallCompleter 与协作实现迁移

- [ ] 3.1 迁移 `FirCallCompleter` 主体逻辑到 `CfirCallCompleter`，保持阶段语义与行为顺序一致
- [ ] 3.2 迁移主逻辑依赖的辅助实现（候选补全、约束补全、诊断协作组件）并完成 CFIR 化命名映射
- [ ] 3.3 清理调用补全链路中的 K1-only 旧设施引用；必须能力在 `cfir` 命名空间内补齐等价实现
- [ ] 3.4 审核并补齐所有依赖声明迁移（导入依赖、模块依赖、类型依赖），确保无“缺失后临时补丁”项
- [ ] 3.5 用上游对位语义实现替换并下线 `CfirConstraintStorage` 及相关简化推断结构，确保调用链仅依赖 CFIR 重实现版 ConstraintStorage 能力
- [ ] 3.6 删除分类为 `K1-only` 的历史设施文件/声明，并更新所有调用点到迁移版或 CFIR 重实现版
- [ ] 3.7 验证代码中未引入 `NewConstraintSystem` / `NewConstraintSystemImpl` / `ConstraintSystemBuilder` 的迁移实现本体

## 4. 验证与回归保护

- [ ] 4.1 为 `CfirCallCompleter` 与关键依赖契约添加/更新模块级测试（构建可编译、关键流程可执行、诊断产物可验证）
- [ ] 4.2 执行受影响模块的定向构建与测试，记录结果与未覆盖风险
- [ ] 4.3 验证 `CFirExpressionsResolveTransformer` 未新增 `CfirCallCompleter` 接线，并在变更说明中明确后续接线待办
- [ ] 4.4 执行“禁止自主实现”审查：所有核心实现均有上游映射依据，未映射项需给出适配理由并评审通过
