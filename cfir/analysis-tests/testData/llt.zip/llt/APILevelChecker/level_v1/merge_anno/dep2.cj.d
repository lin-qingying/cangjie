// Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
// This source file is part of the Cangjie project, licensed under Apache-2.0
// with Runtime Library Exception.
//
// See https://cangjie-lang.cn/pages/LICENSE for license information.

package dep2

@!APILevel[13]
public let cccc: VArray<Int64, $5>
@!APILevel[13]
public let (aaaa, bbbb)
